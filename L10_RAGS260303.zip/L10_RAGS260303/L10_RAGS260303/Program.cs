﻿using System;

namespace L10_RAGS260303
{
    class Program
    {
        static void Main(string[] args)
        {
            TrianguloRectangulo triangulo = new TrianguloRectangulo();
            Console.Write("Ingrese el cateto A: ");
            triangulo.catetoA = double.Parse(Console.ReadLine());

            Console.Write("Ingrese el angulo opuesto a A: ");
            triangulo.anguloOpuestoA = double.Parse(Console.ReadLine());

            Console.Write("Cateto B: " + triangulo.ObtenerCatetoB());
            Console.WriteLine("Hipotenusa: " + triangulo.ObtenerHipotenusa());
            Console.WriteLine("Angulo opuesto a B: " + triangulo.ObtenerAnguloOpuestoB());

            
        }
    }
}

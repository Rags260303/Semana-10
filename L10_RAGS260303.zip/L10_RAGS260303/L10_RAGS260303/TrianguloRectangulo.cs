﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L10_RAGS260303
{
    class TrianguloRectangulo
    {
        public double catetoA;
        public double anguloOpuestoA;

        public double ObtenerCatetoB()
        {
            //tan(anguloOpuestoA) = catA/catB -> catB = catA/(anguloOpuestoA)
            return Math.Round(catetoA / Math.Tan(anguloOpuestoA),3);
        }

        public double ObtenerHipotenusa()
        {
            //sin(angA) = catA/hipotenusa -> hipotenusa = cat/sin(angA)
            return catetoA / Math.Sin(anguloOpuestoA);
        }

        public double ObtenerAnguloOpuestoB()
        {
            // angB + angA 90 -> angB = 90 -angA
            return 90 - anguloOpuestoA;
        }

        public double ObtenerArea()
        {
            return Math.Round(catetoA * ObtenerCatetoB() / 2, 3);
        }
    }
}
